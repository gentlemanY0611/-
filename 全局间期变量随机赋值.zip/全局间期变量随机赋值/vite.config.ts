import { defineConfig } from "vite";

// ESM 库模式：输出 dist/index.mjs
// react、react-dom、@avg-studio/sdk 由 LetsGal Studio 宿主提供单实例，保持 external
export default defineConfig({
  build: {
    lib: {
      entry: "src/index.tsx",
      formats: ["es"],
      fileName: () => "index.mjs",
    },
    rollupOptions: {
      external: ["react", "react-dom", "@avg-studio/sdk"],
    },
    outDir: "dist",
    emptyOutDir: true,
  },
});
