import React, { useEffect } from "react";
import {
  Extension,
  extension,
  method,
  settings,
  useExtensionContext,
  type ExtensionContext,
  type SettingsBuilder,
} from "@avg-studio/sdk";

/* ------------------------------------------------------------------ *
 * 全局间期变量随机赋值（periodic-random-decay）
 *
 * 功能：注册一条规则后，每当「游戏日变量」推进达到设定的间隔天数，
 *       自动把「目标数值变量」随机扣减 [下限, 上限] 区间内的一个整数。
 *       - 全局自动触发：插件在引擎启动时挂载全局监听，只要游戏日变量
 *         发生变化（无论来自哪个选项、章节或剧情）都会自动结算，
 *         不受选项等其他因素影响。
 *       - 剧本选项卡中可以直接选择变量：本扩展的剧本方法使用
 *         type: "variable" 参数，在「调用扩展方法」Block 的属性面板里
 *         会出现变量下拉选择器。
 * ------------------------------------------------------------------ */

/* ----------------------------- 数据结构 ----------------------------- */

/** 规则主体（不含数据库生成 id） */
type DecayRuleData = {
  /** 游戏日变量名：表示游戏推进天数的数值变量 */
  dayVariable: string;
  /** 目标数值变量名：需要被周期扣减的数值 */
  targetVariable: string;
  /** 间隔游戏日数 N：每隔 N 天结算一次 */
  interval: number;
  /** 随机扣减下限（含） */
  minDecrease: number;
  /** 随机扣减上限（含） */
  maxDecrease: number;
  /** 上次结算时的游戏日（用于判断是否到期） */
  lastAppliedDay: number;
  /** 扣减时是否在游戏中显示提示 */
  showHint: boolean;
  /** 方向：decrease=减少，increase=增加 */
  mode: "decrease" | "increase";
};

/** 数据库中的完整规则记录 */
type DecayRule = DecayRuleData & { id: string };

/** 规则集合的最小操作面（与 ctx.database.collection 返回类型兼容） */
interface RulesCollection {
  find(filter?: unknown): Promise<unknown[]>;
  insertOne(data: Record<string, unknown>): Promise<{ id: string }>;
  updateOne(
    filter: Record<string, unknown>,
    update: Record<string, unknown>,
  ): Promise<unknown>;
  deleteOne(filter: Record<string, unknown>): Promise<unknown>;
}

/* ----------------------------- 工具函数 ----------------------------- */

/** 取 [min, max] 闭区间内的随机整数；非法范围自动纠正为 [0, 大] */
function randomInt(min: number, max: number): number {
  const lo = Math.max(0, Math.min(min, max));
  const hi = Math.max(0, Math.max(min, max));
  if (hi === 0) return 0;
  return Math.floor(Math.random() * (hi - lo + 1)) + lo;
}

/** 获取规则集合（规则持久化在项目数据集合中，随存档保存） */
function rulesCollection(ctx: ExtensionContext): RulesCollection {
  return ctx.database.collection("rules") as unknown as RulesCollection;
}

/* ------------------- 全局结算（核心逻辑，串行执行） ------------------ */

/**
 * 串行队列：variable:changed 可能在一瞬间被触发多次
 * （例如结算时写入目标变量也会触发事件），必须保证
 * 结算过程不重叠，否则会出现重复扣减。
 */
let tickQueue: Promise<void> = Promise.resolve();

function enqueueTick(ctx: ExtensionContext): void {
  tickQueue = tickQueue
    .then(() => processAllRules(ctx))
    .catch((err) => console.warn("[全局间期变量随机赋值]", err));
}

/** 遍历全部规则，逐条结算 */
async function processAllRules(ctx: ExtensionContext): Promise<void> {
  const rules = rulesCollection(ctx);
  const all = ((await rules.find({})) ?? []) as DecayRule[];
  for (const rule of all) {
    await processRule(ctx, rules, rule);
  }
}

/** 结算单条规则 */
async function processRule(
  ctx: ExtensionContext,
  rules: RulesCollection,
  rule: DecayRule,
): Promise<void> {
  const day = ctx.variables.get<number>(rule.dayVariable);

  // 游戏日变量还不是数值（未初始化 / 声明类型不对 / 数据损坏）→ 跳过并提示
  if (typeof day !== "number" || !Number.isFinite(day)) {
    console.warn(
      `[全局间期变量随机赋值] 游戏日变量「${rule.dayVariable}」当前不是有效数值，已跳过本次结算。`,
    );
    return;
  }

  // 防御：数据集合被手工编辑成非法值时仍能正常结算
  const interval = Math.max(1, Math.floor(rule.interval) || 1);
  const minD = Number.isFinite(rule.minDecrease) ? rule.minDecrease : 0;
  const maxD = Number.isFinite(rule.maxDecrease) ? rule.maxDecrease : 0;

  // 天数回退（新游戏、返回入口、读更早存档等）→ 立即把基线持久化为当前天，
  // 重新起算；否则旧基线残留在数据中会导致后续永远不再结算。
  let last = rule.lastAppliedDay;
  if (!Number.isFinite(last)) last = day;
  if (day < last) {
    last = day;
    await rules.updateOne(
      { id: rule.id },
      { $set: { lastAppliedDay: day } },
    );
    return;
  }

  const elapsed = day - last;
  if (elapsed < interval) return;

  // 扩展设置里的总开关：关闭时只“追平”天数、不扣减，
  // 避免重新开启后一次性把之前所有周期全部补扣。
  const enabled = ctx.settings.get<boolean>("enabled") ?? true;
  if (!enabled) {
    await rules.updateOne(
      { id: rule.id },
      { $set: { lastAppliedDay: day } },
    );
    return;
  }

  // 计算应结算的完整周期数（支持一次跳过多个周期/多天）
  const times = Math.floor(elapsed / interval);
  let delta = 0;
  for (let i = 0; i < times; i++) {
    delta += randomInt(minD, maxD);
  }

  const mode = rule.mode === "increase" ? "increase" : "decrease";
  const current = ctx.variables.get<number>(rule.targetVariable);
  // 减少方向最低扣到 0；增加方向不设上限
  const next = mode === "increase"
    ? (current ?? 0) + delta
    : Math.max(0, (current ?? 0) - delta);
  ctx.variables.set(rule.targetVariable, next);

  // 写入目标变量会再次触发 variable:changed → 队列中会再跑一次结算；
  // 此时上次结算日已推进，elapsed < interval，不会重复结算。
  await rules.updateOne(
    { id: rule.id },
    { $set: { lastAppliedDay: last + times * interval } },
  );

  const actionText = mode === "increase" ? "增加" : "减少";
  console.log(
    `[全局间期变量随机赋值] ${rule.targetVariable}：${current ?? 0} → ${next}` +
      `（经过 ${times} 个周期，共随机${actionText} ${delta}；游戏日 ${last} → ${last + times * interval}）`,
  );

  if (rule.showHint) {
    void ctx.ui.show("periodic-decay", {
      message: `${rule.targetVariable} ${actionText}了 ${delta} 点（当前 ${next}）`,
    });
  }
}

/* ------------------------------ 扩展本体 ----------------------------- */

@extension({
  id: "periodic-decay",
  label: "全局间期变量随机赋值",
  description:
    "每隔指定游戏日数，自动把目标变量的值随机扣减一个区间内的数值；全局自动触发，不受选项影响，剧本中可直接选择变量。",
})
export class PeriodicDecay extends Extension {
  /** 项目级设置：总开关 */
  static settings = settings((s: SettingsBuilder) => ({
    enabled: s.boolean("启用全局间期随机减益").default(true),
  }));

  /**
   * 模块级全局钩子：引擎启动时注册一次。
   * 监听所有运行时变量变化，只要「游戏日变量」推进到结算点，
   * 无论玩家走到哪个选项分支，都会自动扣减。
   */
  static onRegister(ctx: ExtensionContext): void {
    ctx.subscribe("variable:changed", () => {
      enqueueTick(ctx);
    });
    console.log("[全局间期变量随机赋值] 全局监听已挂载。");
  }

  /** 注册一条全局间期随机赋值规则（可减可加） */
  static registerDecay = method({
    title: "注册全局间期随机赋值",
    description:
      "注册一条规则：从当前游戏日起算，每隔 N 个游戏日，目标变量的值自动随机增加或减少 [下限, 上限] 区间内的一个整数。规则全局自动触发，不受选项影响。",
    schema: {
      dayVariable: {
        type: "variable",
        label: "游戏日变量",
        required: true,
      },
      targetVariable: {
        type: "variable",
        label: "目标数值变量",
        required: true,
      },
      mode: {
        type: "enum",
        label: "操作方向",
        options: [
          { value: "decrease", label: "减少" },
          { value: "increase", label: "增加" },
        ],
        default: "decrease",
        required: true,
      },
      interval: {
        type: "number",
        label: "间隔游戏日数 N",
        min: 1,
        step: 1,
        default: 7,
        required: true,
      },
      minDecrease: {
        type: "number",
        label: "随机变化下限",
        min: 0,
        step: 1,
        default: 1,
        required: true,
      },
      maxDecrease: {
        type: "number",
        label: "随机变化上限",
        min: 0,
        step: 1,
        default: 5,
        required: true,
      },
      showHint: {
        type: "boolean",
        label: "变化时在游戏中显示提示",
        default: true,
      },
    },
    async run(
      ctx: ExtensionContext,
      params: {
        dayVariable: string;
        targetVariable: string;
        mode: "decrease" | "increase";
        interval: number;
        minDecrease: number;
        maxDecrease: number;
        showHint: boolean;
      },
    ): Promise<void> {
      const {
        dayVariable,
        targetVariable,
        mode,
        interval,
        minDecrease,
        maxDecrease,
        showHint,
      } = params;

      if (minDecrease > maxDecrease) {
        console.warn(
          `[全局间期变量随机赋值] 下限(${minDecrease})大于上限(${maxDecrease})，运行时会自动交换处理。`,
        );
      }

      const startDay = ctx.variables.get<number>(dayVariable) ?? 0;
      const rules = rulesCollection(ctx);
      await rules.insertOne({
        dayVariable,
        targetVariable,
        mode,
        interval: Math.max(1, Math.floor(interval)),
        minDecrease,
        maxDecrease,
        lastAppliedDay: startDay,
        showHint,
      });

      const actionText = mode === "increase" ? "增加" : "减少";
      console.log(
        `[全局间期变量随机赋值] 已注册规则：每 ${interval} 个游戏日，` +
          `「${targetVariable}」随机${actionText} ${minDecrease}~${maxDecrease} 点` +
          `（从当前游戏日 ${startDay} 起算）`,
      );
    },
  });

  /** 按“游戏日变量 + 目标数值变量”移除已注册的规则 */
  static removeDecay = method({
    title: "移除全局间期随机减益",
    description:
      "按「游戏日变量 + 目标数值变量」删除已注册的规则，删除后不再自动扣减。",
    schema: {
      dayVariable: {
        type: "variable",
        label: "游戏日变量",
        required: true,
      },
      targetVariable: {
        type: "variable",
        label: "目标数值变量",
        required: true,
      },
    },
    async run(
      ctx: ExtensionContext,
      params: { dayVariable: string; targetVariable: string },
    ): Promise<void> {
      const rules = rulesCollection(ctx);
      const matches = ((await rules.find({
        dayVariable: params.dayVariable,
        targetVariable: params.targetVariable,
      })) ?? []) as DecayRule[];
      for (const rule of matches) {
        await rules.deleteOne({ id: rule.id });
      }
      console.log(
        `[全局间期变量随机赋值] 已移除 ${matches.length} 条规则` +
          `（${params.dayVariable} × ${params.targetVariable}）`,
      );
    },
  });

  /** 清空当前存档中的全部规则 */
  static clearAllDecay = method({
    title: "清空全部间期随机减益规则",
    description: "删除当前存档中注册的全部间期随机减益规则。",
    async run(ctx: ExtensionContext): Promise<void> {
      const rules = rulesCollection(ctx);
      const all = ((await rules.find({})) ?? []) as DecayRule[];
      for (const rule of all) {
        await rules.deleteOne({ id: rule.id });
      }
      console.log(
        `[全局间期变量随机赋值] 已清空全部 ${all.length} 条规则`,
      );
    },
  });

  /** 诊断方法：在游戏中弹出当前状态，方便排查问题 */
  static diagnose = method({
    title: "诊断：打印当前状态",
    description:
      "在游戏画面顶部弹出当前规则数量、每条规则详情、游戏日变量和目标变量的当前值。用于排查为什么扣减不生效。",
    async run(ctx: ExtensionContext): Promise<void> {
      const lines: string[] = [];
      lines.push("=== 诊断 ===");

      try {
        const rules = rulesCollection(ctx);
        const all = ((await rules.find({})) ?? []) as DecayRule[];
        lines.push(`规则总数：${all.length}`);
        for (let i = 0; i < all.length; i++) {
          const r = all[i];
          const day = ctx.variables.get<number>(r.dayVariable);
          const target = ctx.variables.get<number>(r.targetVariable);
          lines.push(
            `#${i + 1} 日=${r.dayVariable}(${day}) 目标=${r.targetVariable}(${target}) ` +
            `${r.mode === "increase" ? "加" : "减"} N=${r.interval} ${r.minDecrease}~${r.maxDecrease} 上次=${r.lastAppliedDay}`,
          );
        }
      } catch (e) {
        lines.push(`读取规则失败：${String(e)}`);
      }

      console.log("[诊断]\n" + lines.join("\n"));
      void ctx.ui.show("periodic-decay", {
        message: lines.join("\n"),
      });
    },
  });

  /** 扣减提示 Toast（可选，注册规则时勾选“显示提示”后出现） */
  render() {
    return {
      component: DecayToast,
      props: this.data ?? { message: "" },
    };
  }
}

/* ------------------------------ 提示 UI ------------------------------ */

type ToastProps = { message?: string };

const DecayToast: React.FC<ToastProps> = ({ message }) => {
  const ctx = useExtensionContext();

  // 展示约 2.5 秒后自动关闭
  useEffect(() => {
    const timer = setTimeout(() => {
      void ctx.ui.hide("periodic-decay");
    }, 2500);
    return () => clearTimeout(timer);
  }, [ctx, message]);

  if (!message) return null;

  return (
    <div
      style={{
        position: "absolute",
        top: 32,
        left: "50%",
        transform: "translateX(-50%)",
        zIndex: 9999,
        maxWidth: "70vw",
        padding: "10px 22px",
        borderRadius: 999,
        background: "rgba(20, 20, 30, 0.85)",
        color: "#fff",
        fontFamily: "sans-serif",
        fontSize: 14,
        whiteSpace: "pre-wrap",
        overflow: "hidden",
        textOverflow: "ellipsis",
        boxShadow: "0 4px 16px rgba(0, 0, 0, 0.35)",
        pointerEvents: "none",
      }}
    >
      {message}
    </div>
  );
};
